# Device Use Statement - Open Nursing Core FHIR Implementation Guide (ONC-IG) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Device Use Statement**

## Resource Profile: Device Use Statement 

| | |
| :--- | :--- |
| *Official URL*:https://opennursingcoreig.com/StructureDefinition/onc-device-use-statement | *Version*:1.0.0 |
| Active as of 2026-07-11 | *Computable Name*:ONCDeviceUseStatement |

 
Documentation of mobility aids or other devices used by the patient. 

**Usages:**

* Examples for this Profile: [DeviceUseStatement/example-device-use](DeviceUseStatement-example-device-use.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/onc.ig|current/StructureDefinition/StructureDefinition-onc-device-use-statement.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-onc-device-use-statement.csv), [Excel](StructureDefinition-onc-device-use-statement.xlsx), [Schematron](StructureDefinition-onc-device-use-statement.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "onc-device-use-statement",
  "url" : "https://opennursingcoreig.com/StructureDefinition/onc-device-use-statement",
  "version" : "1.0.0",
  "name" : "ONCDeviceUseStatement",
  "title" : "Device Use Statement",
  "status" : "active",
  "date" : "2026-07-11T14:32:04+00:00",
  "publisher" : "The Open Nursing Community",
  "description" : "Documentation of mobility aids or other devices used by the patient.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "quick",
    "uri" : "http://siframework.org/cqf",
    "name" : "Quality Improvement and Clinical Knowledge (QUICK)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "DeviceUseStatement",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/DeviceUseStatement",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "DeviceUseStatement",
      "path" : "DeviceUseStatement"
    },
    {
      "id" : "DeviceUseStatement.subject",
      "path" : "DeviceUseStatement.subject",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }]
    },
    {
      "id" : "DeviceUseStatement.timing[x]",
      "path" : "DeviceUseStatement.timing[x]",
      "mustSupport" : true
    },
    {
      "id" : "DeviceUseStatement.bodySite",
      "path" : "DeviceUseStatement.bodySite",
      "mustSupport" : true
    }]
  }
}

```
