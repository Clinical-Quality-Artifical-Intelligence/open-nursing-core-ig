# Home - Open Nursing Core FHIR Implementation Guide (ONC-IG) v1.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://opennursingcoreig.com/ImplementationGuide/onc.ig | *Version*:1.0.0 |
| Active as of 2026-07-09 | *Computable Name*:OpenNursingCoreIG |

# Open Nursing Core FHIR Implementation Guide

> **⚠️ Standards status: Trial Use — Pre-Ballot Community Release.** This IG has **not** undergone formal HL7 standards balloting or independent clinical/peer review. Its `active`/`release` labels reflect development maturity within this project, not endorsement by HL7 International, PRSB, or any other standards body. It is a specification, not a deployed product, and does not by itself discharge an implementing organisation's clinical-safety (DCB0129/DCB0160) or information-governance obligations. See the [Standards & Governance Roadmap](https://github.com/Clinical-Quality-Artifical-Intelligence/open-nursing-core-ig/blob/main/STANDARDS_ROADMAP.md) for the path toward formal review and balloting.

The **Open Nursing Core FHIR Implementation Guide (ONC-IG)** provides a foundational set of standardised, nurse-led data models for the NHS and comparable health systems. It is built on **HL7 FHIR R4 (4.0.1)** and organised around the complete nursing process — **Assessment, Diagnosis, Planning, Implementation and Evaluation (ADPIE)** — rather than a purely pathology-driven medical model.

The IG is grounded in United Kingdom nursing and information standards, in particular the **Professional Record Standards Body (PRSB)** Nursing Care Needs standard, the **NANDA International (NANDA-I)** diagnostic taxonomy, and the person-centred practice principles of the **Foundation of Nursing Studies (FONS)**.

## Purpose and scope

This guide defines the structured data required to record nursing care in an interoperable, equitable and safety-aware manner. It is intended for use by NHS digital teams, electronic health record (EHR) suppliers, clinical safety officers, and nurse informaticians who need a shared vocabulary for the fundamentals of nursing.

The current release defines **60 profiles**, **27 value sets**, **3 code systems**, **4 extensions**, **1 logical model** (the Relational Care model) and **49 worked examples**. See the [Published Versions](history.md) page for the full release record.

## Core principles

* **Process-led** — every profile maps to a phase of the [ADPIE nursing process](adpie.md), making the **reasoning** of care computable, not only its outcomes.
* **Person-centred** — captures "[What Matters to Me](StructureDefinition-onc-what-matters.md)" and the [Patient Story](StructureDefinition-onc-patient-story.md) alongside clinical measurement, in line with FONS values-based practice.
* **Equitable by design** — leads with the [Monk Skin Tone Scale](equity.md) for skin assessment and records [Reasonable Adjustments](StructureDefinition-onc-reasonable-adjustment.md) under the Equality Act 2010. See the [Health Equity & Inclusion](equity.md) page.
* **Safety-aware** — validated instruments such as [NEWS2](StructureDefinition-onc-news2-score.md) and pressure-ulcer risk scores act as clinical [safety gates](safety.md).

## Profile library

The profile library is organised below by function. For the full navigable list of every artifact, see the [Artifacts](artifacts.md) index.

### 1. Nursing process core

Base profiles that carry the ADPIE spine.

* [ONC Nursing Assessment](StructureDefinition-onc-nursing-assessment.md) — the base observation for all assessment instruments
* [ONC Nursing Problem](StructureDefinition-onc-nursing-problem.md) — nursing diagnosis (Condition)
* [ONC Nursing Need](StructureDefinition-onc-nursing-need.md) and [ONC Nursing Strength](StructureDefinition-onc-nursing-strength.md) — PRSB needs-and-strengths framing
* [ONC Nursing Goal](StructureDefinition-onc-nursing-goal.md) — planned outcomes
* [ONC Nursing Intervention](StructureDefinition-onc-nursing-intervention.md) — delivered care
* [ONC Goal Evaluation](StructureDefinition-onc-goal-evaluation.md) and [ONC Nursing Clinical Impression](StructureDefinition-onc-nursing-clinical-impression.md) — evaluation

### 2. Clinical safety and deterioration

Validated risk instruments used as safety gates. See the [Clinical Safety](safety.md) page.

* [NEWS2](StructureDefinition-onc-news2-score.md) — National Early Warning Score 2 (deterioration)
* [Braden Scale](StructureDefinition-onc-braden-scale-assessment.md) and [Waterlow Score](StructureDefinition-onc-waterlow-score.md) — pressure-ulcer risk
* [MUST](StructureDefinition-onc-must-score.md) — malnutrition screening
* [4AT Delirium Screen](StructureDefinition-onc-4at-delirium.md), [Morse Fall Scale](StructureDefinition-onc-morse-fall-scale.md), [qSOFA](StructureDefinition-onc-qsofa.md)

### 3. Relational and inclusive care

Capturing the person behind the patient. See [Health Equity & Inclusion](equity.md).

* [What Matters To Me](StructureDefinition-onc-what-matters.md) and [Patient Story](StructureDefinition-onc-patient-story.md)
* [Monk Skin Tone Observation](StructureDefinition-onc-monk-skintone-observation.md) — 10-point equitable skin assessment (A–J)
* [Skin Tone Observation](StructureDefinition-onc-skintone-observation.md) — Fitzpatrick classification (secondary)
* [Reasonable Adjustment](StructureDefinition-onc-reasonable-adjustment.md) — Equality Act 2010
* [Mental Capacity Assessment](StructureDefinition-onc-mental-capacity.md) — Mental Capacity Act 2005

### 4. Fundamental care

The essentials of daily nursing.

* [Bristol Stool Chart](StructureDefinition-onc-bristol-stool-chart.md) — elimination
* [Fluid Balance](StructureDefinition-onc-fluid-balance.md) — hydration
* [Abbey Pain Scale](StructureDefinition-onc-abbey-pain-scale.md) — non-verbal pain
* [Oral Health](StructureDefinition-onc-oral-health.md) and [Sleep Pattern](StructureDefinition-onc-sleep-pattern.md)

### 5. Specialist and mental health

Instruments for learning disability, mental health and older-person care.

* [ABC Chart](StructureDefinition-onc-abc-chart.md) — Positive Behaviour Support
* [Seizure Record](StructureDefinition-onc-seizure-record.md) — epilepsy
* [Clinical Frailty Scale](StructureDefinition-onc-clinical-frailty-scale.md) and [Glasgow Coma Scale](StructureDefinition-onc-glasgow-coma-scale.md)
* [MMSE](StructureDefinition-onc-mmse.md), [Urinalysis](StructureDefinition-onc-urinalysis.md)

## Guidance pages

* [The ADPIE Nursing Process](adpie.md) — how the IG is structured around clinical reasoning
* [Clinical Safety](safety.md) — safety gates, escalation and the DCB0129/0160 context
* [Health Equity & Inclusion](equity.md) — Monk Skin Tone Scale and reasonable adjustments
* [Security & Privacy](security.md) — UK GDPR, DSPT and Caldicott
* [Terminology](terminology.md) — SNOMED CT, LOINC and the ONC code systems
* [Relational AI](relation-ai.md) — the FONS-aligned language model
* [Published Versions](history.md) — release history

## Getting started

1. **Browse the artifacts**— every profile, extension, value set and example is listed on the[Artifacts](artifacts.md)page.
1. **Read the process guide**— start with[ADPIE](adpie.md)to understand how the profiles fit together.
1. **Contribute**— the IG is open source under the MIT licence. Issues and pull requests are welcome on[GitHub](https://github.com/Clinical-Quality-Artifical-Intelligence/open-nursing-core-ig).

-------

**The Open Nursing Core is maintained by the Open Nursing Community. This guide is a technical specification and does not replace professional clinical judgement; all clinical documentation must be verified by a registered nurse.**

