# Home - Open Nursing Core FHIR Implementation Guide (ONC-IG) v1.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://opennursingcoreig.com/ImplementationGuide/onc.ig | *Version*:1.0.0 |
| Active as of 2026-07-11 | *Computable Name*:OpenNursingCoreIG |

# Open Nursing Core FHIR Implementation Guide

> **⚠️ Standards status: Trial Use — Pre-Ballot Community Release.** This IG has **not** undergone formal HL7 standards balloting or independent clinical/peer review. Its `active`/`release` labels reflect development maturity within this project, not endorsement by HL7 International, PRSB, or any other standards body. It is a specification, not a deployed product, and does not by itself discharge an implementing organisation's clinical-safety (DCB0129/DCB0160) or information-governance obligations. See the [Standards & Governance Roadmap](https://github.com/Clinical-Quality-Artifical-Intelligence/open-nursing-core-ig/blob/main/STANDARDS_ROADMAP.md) for the path toward formal review and balloting.

The **Open Nursing Core FHIR Implementation Guide (ONC-IG)** provides a foundational set of standardised, nurse-led data models for the NHS and comparable health systems. It is built on **HL7 FHIR R4 (4.0.1)** and organised around the complete nursing process — **Assessment, Diagnosis, Planning, Implementation and Evaluation (ADPIE)** — rather than a purely pathology-driven medical model.

The IG is grounded in United Kingdom nursing and information standards, in particular the **Professional Record Standards Body (PRSB)** Nursing Care Needs standard, the **NANDA International (NANDA-I)** diagnostic taxonomy, and the person-centred practice principles of the **Foundation of Nursing Studies (FONS)**.

## Purpose and scope

This guide defines the structured data required to record nursing care in an interoperable, equitable and safety-aware manner. It is intended for use by NHS digital teams, electronic health record (EHR) suppliers, clinical safety officers, and nurse informaticians who need a shared vocabulary for the fundamentals of nursing.

The current release defines **60 profiles**, **27 value sets**, **3 code systems**, **4 extensions**, **1 logical model** (the Relational Care model) and **49 worked examples**. See the [Published Versions](history.md) page for the full release record.

## Core principles

* **Process-led** — every profile maps to a phase of the [ADPIE nursing process](adpie.md), making the **reasoning** of care computable, not only its outcomes.
* **Person-centred** — captures "[What Matters to Me](StructureDefinition-onc-what-matters.md)" and the [Patient Story](StructureDefinition-onc-patient-story.md) alongside clinical measurement, in line with FONS values-based practice.
* **Equitable by design** — leads with the [Monk Skin Tone Scale](equity.md) for skin assessment and records [Reasonable Adjustments](StructureDefinition-onc-reasonable-adjustment.md) under the Equality Act 2010. See the [Health Equity & Inclusion](equity.md) page.
* **Safety-aware** — validated instruments such as [NEWS2](StructureDefinition-onc-news2-score.md) and pressure-ulcer risk scores act as clinical [safety gates](safety.md).

## Profile library

The profile library is organised below by function. For the full navigable list of every artifact, see the [Artifacts](artifacts.md) index.

### 1. Nursing process core

Base profiles that carry the ADPIE spine.

* [ONC Nursing Assessment](StructureDefinition-onc-nursing-assessment.md) — the base observation for all assessment instruments
* [ONC Nursing Problem](StructureDefinition-onc-nursing-problem.md) — nursing diagnosis (Condition)
* [ONC Nursing Need](StructureDefinition-onc-nursing-need.md) and [ONC Nursing Strength](StructureDefinition-onc-nursing-strength.md) — PRSB needs-and-strengths framing
* [ONC Nursing Goal](StructureDefinition-onc-nursing-goal.md) — planned outcomes
* [ONC Nursing Intervention](StructureDefinition-onc-nursing-intervention.md) — delivered care
* [ONC Goal Evaluation](StructureDefinition-onc-goal-evaluation.md) and [ONC Nursing Clinical Impression](StructureDefinition-onc-nursing-clinical-impression.md) — evaluation

### 2. Clinical safety and deterioration

Validated risk instruments used as safety gates. See the [Clinical Safety](safety.md) page.

* [NEWS2](StructureDefinition-onc-news2-score.md) — National Early Warning Score 2 (deterioration)
* [Braden Scale](StructureDefinition-onc-braden-scale-assessment.md) and [Waterlow Score](StructureDefinition-onc-waterlow-score.md) — pressure-ulcer risk
* [MUST](StructureDefinition-onc-must-score.md) — malnutrition screening
* [4AT Delirium Screen](StructureDefinition-onc-4at-delirium.md), [Morse Fall Scale](StructureDefinition-onc-morse-fall-scale.md), [qSOFA](StructureDefinition-onc-qsofa.md)

### 3. Relational and inclusive care

Capturing the person behind the patient. See [Health Equity & Inclusion](equity.md).

* [What Matters To Me](StructureDefinition-onc-what-matters.md) and [Patient Story](StructureDefinition-onc-patient-story.md)
* [Monk Skin Tone Observation](StructureDefinition-onc-monk-skintone-observation.md) — 10-point equitable skin assessment (A–J)
* [Skin Tone Observation](StructureDefinition-onc-skintone-observation.md) — Fitzpatrick classification (secondary)
* [Reasonable Adjustment](StructureDefinition-onc-reasonable-adjustment.md) — Equality Act 2010
* [Mental Capacity Assessment](StructureDefinition-onc-mental-capacity.md) — Mental Capacity Act 2005

### 4. Fundamental care

The essentials of daily nursing.

* [Bristol Stool Chart](StructureDefinition-onc-bristol-stool-chart.md) — elimination
* [Fluid Balance](StructureDefinition-onc-fluid-balance.md) — hydration
* [Abbey Pain Scale](StructureDefinition-onc-abbey-pain-scale.md) — non-verbal pain
* [Oral Health](StructureDefinition-onc-oral-health.md) and [Sleep Pattern](StructureDefinition-onc-sleep-pattern.md)

### 5. Specialist and mental health

Instruments for learning disability, mental health and older-person care.

* [ABC Chart](StructureDefinition-onc-abc-chart.md) — Positive Behaviour Support
* [Seizure Record](StructureDefinition-onc-seizure-record.md) — epilepsy
* [Clinical Frailty Scale](StructureDefinition-onc-clinical-frailty-scale.md) and [Glasgow Coma Scale](StructureDefinition-onc-glasgow-coma-scale.md)
* [MMSE](StructureDefinition-onc-mmse.md), [Urinalysis](StructureDefinition-onc-urinalysis.md)

## Guidance pages

* [The ADPIE Nursing Process](adpie.md) — how the IG is structured around clinical reasoning
* [Clinical Safety](safety.md) — safety gates, escalation and the DCB0129/0160 context
* [Health Equity & Inclusion](equity.md) — Monk Skin Tone Scale and reasonable adjustments
* [Security & Privacy](security.md) — UK GDPR, DSPT and Caldicott
* [Terminology](terminology.md) — SNOMED CT, LOINC and the ONC code systems
* [Structured Data Capture](questionnaires.md) — SDC Questionnaires for offline-first capture (Open Health Stack compatible)
* [Relational AI](relation-ai.md) — the FONS-aligned language model
* [Published Versions](history.md) — release history

## Getting started

1. **Browse the artifacts**— every profile, extension, value set and example is listed on the[Artifacts](artifacts.md)page.
1. **Read the process guide**— start with[ADPIE](adpie.md)to understand how the profiles fit together.
1. **Contribute**— the IG is open source under the MIT licence. Issues and pull requests are welcome on[GitHub](https://github.com/Clinical-Quality-Artifical-Intelligence/open-nursing-core-ig).

## Dependencies and intellectual property

This IG builds on the following specifications and terminologies:




### Cross-version analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (onc.ig.r4)](package.r4.tgz) and [R4B (onc.ig.r4b)](package.r4b.tgz) are available.

### Global profiles

*There are no Global profiles defined*

### Intellectual property statements

This publication includes IP covered under the following statements.

* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* LOINC: [Goal/example-patient-goal](Goal-example-patient-goal.md), [ONCBloodPressure](StructureDefinition-onc-blood-pressure.md)... Show 28 more, [ONCBodyTemperature](StructureDefinition-onc-body-temperature.md), [ONCGlasgowComaScale](StructureDefinition-onc-glasgow-coma-scale.md), [ONCGoalTargetMeasureVS](ValueSet-onc-goal-target-measure-vs.md), [ONCHeartRate](StructureDefinition-onc-heart-rate.md), [ONCInspiredOxygen](StructureDefinition-onc-inspired-oxygen.md), [ONCMMSE](StructureDefinition-onc-mmse.md), [ONCMorseFallScale](StructureDefinition-onc-morse-fall-scale.md), [ONCNEWS2Questionnaire](Questionnaire-onc-news2-questionnaire.md), [ONCNursingGoal](StructureDefinition-onc-nursing-goal.md), [ONCOxygenSaturation](StructureDefinition-onc-oxygen-saturation.md), [ONCPainAssessment](StructureDefinition-onc-pain-assessment.md), [ONCRespirationRate](StructureDefinition-onc-respiration-rate.md), [ONCSkinToneObservation](StructureDefinition-onc-skintone-observation.md), [ONCqSOFA](StructureDefinition-onc-qsofa.md), [Observation/example-blood-pressure](Observation-example-blood-pressure.md), [Observation/example-gcs](Observation-example-gcs.md), [Observation/example-heart-rate](Observation-example-heart-rate.md), [Observation/example-inspired-oxygen](Observation-example-inspired-oxygen.md), [Observation/example-mmse](Observation-example-mmse.md), [Observation/example-morse-fall](Observation-example-morse-fall.md), [Observation/example-nursing-assessment](Observation-example-nursing-assessment.md), [Observation/example-oxygen-saturation](Observation-example-oxygen-saturation.md), [Observation/example-pain-nrs](Observation-example-pain-nrs.md), [Observation/example-qsofa](Observation-example-qsofa.md), [Observation/example-respiration-rate](Observation-example-respiration-rate.md), [Observation/example-temperature](Observation-example-temperature.md), [Observation/observation-skin-tone](Observation-observation-skin-tone.md) and [PainAssessmentCodeValueSet](ValueSet-pain-assessment-code-vs.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [ACVPUValueSet](ValueSet-acvpu-vs.md), [AMT4VS](ValueSet-onc-4at-amt4-vs.md)... Show 58 more, [AcuteChangeVS](ValueSet-onc-4at-acute-change-vs.md), [AlertnessVS](ValueSet-onc-4at-alertness-vs.md), [AttentionVS](ValueSet-onc-4at-attention-vs.md), [Goal/example-patient-goal](Goal-example-patient-goal.md), [GoalEvaluationValueSet](ValueSet-goal-evaluation-valueset.md), [HousingStatusVS](ValueSet-housing-status-vs.md), [InspiredOxygenValueSet](ValueSet-inspired-oxygen-vs.md), [NEWS2ScoreVS](ValueSet-onc-news2-score-vs.md), [NEWS2_Escalation_Protocol](PlanDefinition-news2-escalation-plan.md), [NursingInterventionValueSet](ValueSet-nursing-intervention-valueset.md), [NursingProblemValueSet](ValueSet-nursing-problem-valueset.md), [ONC4ATDelirium](StructureDefinition-onc-4at-delirium.md), [ONCACVPU](StructureDefinition-onc-acvpu.md), [ONCBladderAssessment](StructureDefinition-onc-bladder-assessment.md), [ONCBowelAssessment](StructureDefinition-onc-bowel-assessment.md), [ONCCatheterCare](StructureDefinition-onc-catheter-care.md), [ONCContinenceAssessment](StructureDefinition-onc-continence-assessment.md), [ONCDietaryRequirements](StructureDefinition-onc-dietary-requirements.md), [ONCDressingAssessment](StructureDefinition-onc-dressing-assessment.md), [ONCGoalEvaluation](StructureDefinition-onc-goal-evaluation.md), [ONCGoalTargetMeasureVS](ValueSet-onc-goal-target-measure-vs.md), [ONCHygieneAssessment](StructureDefinition-onc-hygiene-assessment.md), [ONCInspiredOxygen](StructureDefinition-onc-inspired-oxygen.md), [ONCMedicationAbility](StructureDefinition-onc-medication-ability.md), [ONCMedicationSelfAdmin](StructureDefinition-onc-medication-self-admin.md), [ONCMobilityAssessment](StructureDefinition-onc-mobility-assessment.md), [ONCNEWS2Questionnaire](Questionnaire-onc-news2-questionnaire.md), [ONCNursingClinicalImpression](StructureDefinition-onc-nursing-clinical-impression.md), [ONCNursingGoal](StructureDefinition-onc-nursing-goal.md), [ONCNursingIntervention](StructureDefinition-onc-nursing-intervention.md), [ONCNursingProblem](StructureDefinition-onc-nursing-problem.md), [ONCOralCareAssessment](StructureDefinition-onc-oral-care-assessment.md), [ONCOralIntakeAssessment](StructureDefinition-onc-oral-intake-assessment.md), [ONCPrognosisVS](ValueSet-onc-prognosis-vs.md), [ONCRelationalOutcomesVS](ValueSet-onc-relational-outcomes-vs.md), [ONCSkinAssessment](StructureDefinition-onc-skin-assessment.md), [ONCSwallowingAssessment](StructureDefinition-onc-swallowing-assessment.md), [ONCWoundAssessment](StructureDefinition-onc-wound-assessment.md), [Observation/ExampleDressingAssessment](Observation-ExampleDressingAssessment.md), [Observation/ExampleSkinAssessment](Observation-ExampleSkinAssessment.md), [Observation/example-acvpu](Observation-example-acvpu.md), [Observation/example-bladder-assessment](Observation-example-bladder-assessment.md), [Observation/example-bowel-assessment](Observation-example-bowel-assessment.md), [Observation/example-catheter-care](Observation-example-catheter-care.md), [Observation/example-continence-assessment](Observation-example-continence-assessment.md), [Observation/example-dietary-requirements](Observation-example-dietary-requirements.md), [Observation/example-goal-evaluation](Observation-example-goal-evaluation.md), [Observation/example-hygiene-assessment](Observation-example-hygiene-assessment.md), [Observation/example-inspired-oxygen](Observation-example-inspired-oxygen.md), [Observation/example-medication-ability](Observation-example-medication-ability.md), [Observation/example-medication-self-admin](Observation-example-medication-self-admin.md), [Observation/example-mobility-assessment](Observation-example-mobility-assessment.md), [Observation/example-oral-care-assessment](Observation-example-oral-care-assessment.md), [Observation/example-oral-intake](Observation-example-oral-intake.md), [Observation/example-swallowing-assessment](Observation-example-swallowing-assessment.md), [Observation/example-wound-assessment](Observation-example-wound-assessment.md), [PainScoreVS](ValueSet-onc-pain-score-vs.md) and [Procedure/example-nursing-intervention](Procedure-example-nursing-intervention.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Condition Category Codes](http://terminology.hl7.org/7.2.0/CodeSystem-condition-category.html): [ONCNursingNeed](StructureDefinition-onc-nursing-need.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.2.0/CodeSystem-condition-clinical.html): [Condition/ExampleNursingNeed-Dressing](Condition-ExampleNursingNeed-Dressing.md) and [Condition/example-nursing-problem](Condition-example-nursing-problem.md)
* [ConditionVerificationStatus](http://terminology.hl7.org/7.2.0/CodeSystem-condition-ver-status.html): [Condition/ExampleNursingNeed-Dressing](Condition-ExampleNursingNeed-Dressing.md)
* [Goal category](http://terminology.hl7.org/7.2.0/CodeSystem-goal-category.html): [ONCNursingGoal](StructureDefinition-onc-nursing-goal.md)
* [LibraryType](http://terminology.hl7.org/7.2.0/CodeSystem-library-type.html): [ONC_NEWS2_Logic](Library-onc-news2-cql.md)
* [Observation Category Codes](http://terminology.hl7.org/7.2.0/CodeSystem-observation-category.html): [ONC4ATDelirium](StructureDefinition-onc-4at-delirium.md), [ONCABCChart](StructureDefinition-onc-abc-chart.md)... Show 100 more, [ONCACVPU](StructureDefinition-onc-acvpu.md), [ONCAbbeyPainScale](StructureDefinition-onc-abbey-pain-scale.md), [ONCBarthelIndex](StructureDefinition-onc-barthel-index.md), [ONCBladderAssessment](StructureDefinition-onc-bladder-assessment.md), [ONCBloodPressure](StructureDefinition-onc-blood-pressure.md), [ONCBodyTemperature](StructureDefinition-onc-body-temperature.md), [ONCBowelAssessment](StructureDefinition-onc-bowel-assessment.md), [ONCBradenScaleAssessment](StructureDefinition-onc-braden-scale-assessment.md), [ONCBristolStoolChart](StructureDefinition-onc-bristol-stool-chart.md), [ONCCatheterCare](StructureDefinition-onc-catheter-care.md), [ONCClinicalFrailtyScale](StructureDefinition-onc-clinical-frailty-scale.md), [ONCContinenceAssessment](StructureDefinition-onc-continence-assessment.md), [ONCDietaryRequirements](StructureDefinition-onc-dietary-requirements.md), [ONCDressingAssessment](StructureDefinition-onc-dressing-assessment.md), [ONCFluidBalance](StructureDefinition-onc-fluid-balance.md), [ONCGlasgowComaScale](StructureDefinition-onc-glasgow-coma-scale.md), [ONCHeartRate](StructureDefinition-onc-heart-rate.md), [ONCHygieneAssessment](StructureDefinition-onc-hygiene-assessment.md), [ONCInspiredOxygen](StructureDefinition-onc-inspired-oxygen.md), [ONCMMSE](StructureDefinition-onc-mmse.md), [ONCMUSTScore](StructureDefinition-onc-must-score.md), [ONCMedicationAbility](StructureDefinition-onc-medication-ability.md), [ONCMedicationSelfAdmin](StructureDefinition-onc-medication-self-admin.md), [ONCMentalCapacity](StructureDefinition-onc-mental-capacity.md), [ONCMobilityAssessment](StructureDefinition-onc-mobility-assessment.md), [ONCMonkSkinToneObservation](StructureDefinition-onc-monk-skintone-observation.md), [ONCMorseFallScale](StructureDefinition-onc-morse-fall-scale.md), [ONCNEWS2Score](StructureDefinition-onc-news2-score.md), [ONCNEWS2Subscore](StructureDefinition-onc-news2-subscore.md), [ONCNursingAssessment](StructureDefinition-onc-nursing-assessment.md), [ONCOralCareAssessment](StructureDefinition-onc-oral-care-assessment.md), [ONCOralHealth](StructureDefinition-onc-oral-health.md), [ONCOralIntakeAssessment](StructureDefinition-onc-oral-intake-assessment.md), [ONCOxygenSaturation](StructureDefinition-onc-oxygen-saturation.md), [ONCPainAssessment](StructureDefinition-onc-pain-assessment.md), [ONCPatientStory](StructureDefinition-onc-patient-story.md), [ONCReasonableAdjustment](StructureDefinition-onc-reasonable-adjustment.md), [ONCRelationalObservation](StructureDefinition-onc-relational-observation.md), [ONCRespirationRate](StructureDefinition-onc-respiration-rate.md), [ONCSeizureRecord](StructureDefinition-onc-seizure-record.md), [ONCSkinAssessment](StructureDefinition-onc-skin-assessment.md), [ONCSkinToneObservation](StructureDefinition-onc-skintone-observation.md), [ONCSleepPattern](StructureDefinition-onc-sleep-pattern.md), [ONCSwallowingAssessment](StructureDefinition-onc-swallowing-assessment.md), [ONCUrinalysis](StructureDefinition-onc-urinalysis.md), [ONCWaterlowScore](StructureDefinition-onc-waterlow-score.md), [ONCWhatMattersToMe](StructureDefinition-onc-what-matters.md), [ONCWoundAssessment](StructureDefinition-onc-wound-assessment.md), [ONCqSOFA](StructureDefinition-onc-qsofa.md), [Observation/ExampleDressingAssessment](Observation-ExampleDressingAssessment.md), [Observation/ExampleSkinAssessment](Observation-ExampleSkinAssessment.md), [Observation/example-4at-delirium](Observation-example-4at-delirium.md), [Observation/example-abbey-pain](Observation-example-abbey-pain.md), [Observation/example-abc-chart](Observation-example-abc-chart.md), [Observation/example-acvpu](Observation-example-acvpu.md), [Observation/example-barthel-index](Observation-example-barthel-index.md), [Observation/example-bladder-assessment](Observation-example-bladder-assessment.md), [Observation/example-blood-pressure](Observation-example-blood-pressure.md), [Observation/example-bowel-assessment](Observation-example-bowel-assessment.md), [Observation/example-bristol-stool](Observation-example-bristol-stool.md), [Observation/example-catheter-care](Observation-example-catheter-care.md), [Observation/example-clinical-frailty](Observation-example-clinical-frailty.md), [Observation/example-continence-assessment](Observation-example-continence-assessment.md), [Observation/example-dietary-requirements](Observation-example-dietary-requirements.md), [Observation/example-fluid-balance](Observation-example-fluid-balance.md), [Observation/example-gcs](Observation-example-gcs.md), [Observation/example-goal-evaluation](Observation-example-goal-evaluation.md), [Observation/example-heart-rate](Observation-example-heart-rate.md), [Observation/example-hygiene-assessment](Observation-example-hygiene-assessment.md), [Observation/example-inspired-oxygen](Observation-example-inspired-oxygen.md), [Observation/example-medication-ability](Observation-example-medication-ability.md), [Observation/example-medication-self-admin](Observation-example-medication-self-admin.md), [Observation/example-mental-capacity](Observation-example-mental-capacity.md), [Observation/example-mmse](Observation-example-mmse.md), [Observation/example-mobility-assessment](Observation-example-mobility-assessment.md), [Observation/example-monk-skin-tone](Observation-example-monk-skin-tone.md), [Observation/example-morse-fall](Observation-example-morse-fall.md), [Observation/example-must-score](Observation-example-must-score.md), [Observation/example-news2-score](Observation-example-news2-score.md), [Observation/example-news2-subscore](Observation-example-news2-subscore.md), [Observation/example-nursing-assessment](Observation-example-nursing-assessment.md), [Observation/example-oral-care-assessment](Observation-example-oral-care-assessment.md), [Observation/example-oral-health](Observation-example-oral-health.md), [Observation/example-oral-intake](Observation-example-oral-intake.md), [Observation/example-oxygen-saturation](Observation-example-oxygen-saturation.md), [Observation/example-pain-nrs](Observation-example-pain-nrs.md), [Observation/example-patient-story](Observation-example-patient-story.md), [Observation/example-qsofa](Observation-example-qsofa.md), [Observation/example-reasonable-adjustment](Observation-example-reasonable-adjustment.md), [Observation/example-respiration-rate](Observation-example-respiration-rate.md), [Observation/example-seizure-record](Observation-example-seizure-record.md), [Observation/example-sleep-pattern](Observation-example-sleep-pattern.md), [Observation/example-swallowing-assessment](Observation-example-swallowing-assessment.md), [Observation/example-temperature](Observation-example-temperature.md), [Observation/example-urinalysis](Observation-example-urinalysis.md), [Observation/example-waterlow-score](Observation-example-waterlow-score.md), [Observation/example-what-matters](Observation-example-what-matters.md), [Observation/example-wound-assessment](Observation-example-wound-assessment.md), [Observation/observation-braden-scale](Observation-observation-braden-scale.md) and [Observation/observation-skin-tone](Observation-observation-skin-tone.md)
* [PlanDefinitionType](http://terminology.hl7.org/7.2.0/CodeSystem-plan-definition-type.html): [NEWS2_Escalation_Protocol](PlanDefinition-news2-escalation-plan.md)


-------

**The Open Nursing Core is maintained by the Open Nursing Community. This guide is a technical specification and does not replace professional clinical judgement; all clinical documentation must be verified by a registered nurse.**

