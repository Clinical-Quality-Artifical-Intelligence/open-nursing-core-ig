# Pain Score Value Set - Open Nursing Core FHIR Implementation Guide (ONC-IG) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Pain Score Value Set**

## ValueSet: Pain Score Value Set 

| | |
| :--- | :--- |
| *Official URL*:https://opennursingcoreig.com/ValueSet/onc-pain-score-vs | *Version*:1.0.0 |
| Active as of 2026-07-04 | *Computable Name*:PainScoreVS |

 
Standard 0-10 or Abbey Pain Scale score 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "onc-pain-score-vs",
  "url" : "https://opennursingcoreig.com/ValueSet/onc-pain-score-vs",
  "version" : "1.0.0",
  "name" : "PainScoreVS",
  "title" : "Pain Score Value Set",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-04T09:17:49+00:00",
  "publisher" : "The Open Nursing Community",
  "description" : "Standard 0-10 or Abbey Pain Scale score",
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "260385009",
        "display" : "Negative"
      },
      {
        "code" : "225330006",
        "display" : "Pain score"
      }]
    },
    {
      "system" : "https://opennursingcoreig.com/CodeSystem/onc-observation-codes",
      "filter" : [{
        "property" : "code",
        "op" : "is-a",
        "value" : "abbey-score"
      }]
    }]
  }
}

```
