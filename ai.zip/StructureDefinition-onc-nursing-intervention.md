# ONC Nursing Intervention - Open Nursing Core FHIR Implementation Guide (ONC-IG) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ONC Nursing Intervention**

## Resource Profile: ONC Nursing Intervention 

| | |
| :--- | :--- |
| *Official URL*:https://opennursingcoreig.com/StructureDefinition/onc-nursing-intervention | *Version*:1.0.0 |
| Active as of 2026-01-27 | *Computable Name*:ONCNursingIntervention |

 
Nursing intervention performed to achieve patient goals. Part of ADPIE Implementation phase. 

**Usages:**

* Examples for this Profile: [Procedure/example-nursing-intervention](Procedure-example-nursing-intervention.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/onc.ig|current/StructureDefinition/onc-nursing-intervention)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-onc-nursing-intervention.csv), [Excel](StructureDefinition-onc-nursing-intervention.xlsx), [Schematron](StructureDefinition-onc-nursing-intervention.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "onc-nursing-intervention",
  "url" : "https://opennursingcoreig.com/StructureDefinition/onc-nursing-intervention",
  "version" : "1.0.0",
  "name" : "ONCNursingIntervention",
  "title" : "ONC Nursing Intervention",
  "status" : "active",
  "date" : "2026-01-27T00:24:44+00:00",
  "publisher" : "The Open Nursing Community",
  "description" : "Nursing intervention performed to achieve patient goals. Part of ADPIE Implementation phase.",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "workflow",
      "uri" : "http://hl7.org/fhir/workflow",
      "name" : "Workflow Pattern"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Procedure",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Procedure",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Procedure",
        "path" : "Procedure"
      },
      {
        "id" : "Procedure.extension",
        "path" : "Procedure.extension",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "value",
              "path" : "url"
            }
          ],
          "ordered" : false,
          "rules" : "open"
        }
      },
      {
        "id" : "Procedure.extension:interventionGoal",
        "path" : "Procedure.extension",
        "sliceName" : "interventionGoal",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "https://opennursingcoreig.com/StructureDefinition/intervention-goal-reference"
            ]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "Procedure.status",
        "path" : "Procedure.status",
        "patternCode" : "completed",
        "mustSupport" : true
      },
      {
        "id" : "Procedure.code",
        "path" : "Procedure.code",
        "min" : 1,
        "mustSupport" : true,
        "binding" : {
          "strength" : "required",
          "valueSet" : "https://opennursingcoreig.com/ValueSet/nursing-intervention-valueset"
        }
      }
    ]
  }
}

```
