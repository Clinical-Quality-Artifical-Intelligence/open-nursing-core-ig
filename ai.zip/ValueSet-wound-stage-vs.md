# Wound Stage Value Set - Open Nursing Core FHIR Implementation Guide (ONC-IG) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Wound Stage Value Set**

## ValueSet: Wound Stage Value Set 

| | |
| :--- | :--- |
| *Official URL*:https://opennursingcoreig.com/ValueSet/wound-stage-vs | *Version*:1.0.0 |
| Active as of 2026-07-11 | *Computable Name*:WoundStageValueSet |

 **References** 

* [Wound Assessment](StructureDefinition-onc-wound-assessment.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "wound-stage-vs",
  "url" : "https://opennursingcoreig.com/ValueSet/wound-stage-vs",
  "version" : "1.0.0",
  "name" : "WoundStageValueSet",
  "title" : "Wound Stage Value Set",
  "status" : "active",
  "date" : "2026-07-11T09:35:24+00:00",
  "publisher" : "The Open Nursing Community",
  "compose" : {
    "include" : [{
      "system" : "https://opennursingcoreig.com/CodeSystem/onc-observation-codes",
      "concept" : [{
        "code" : "stage-1"
      },
      {
        "code" : "stage-2"
      },
      {
        "code" : "stage-3"
      },
      {
        "code" : "stage-4"
      },
      {
        "code" : "unstageable"
      },
      {
        "code" : "deep-tissue"
      }]
    }]
  }
}

```
