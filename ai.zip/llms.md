# onc.ig#0.1.0: Open Nursing Core FHIR Implementation Guide (ONC-IG)

## Pages

* [Home](index.md)
* [Relational Ai (AI Model)](relation-ai.md)
* [Artifacts Summary](artifacts.md)
* [Published Versions](history.md)

## Resources

### CodeSystems

* [Monk Skin Tone Scale CodeSystem](CodeSystem-onc-monk-scale.md)
* [ONC Observation Codes](CodeSystem-onc-observation-codes.md)
* [Problem Type CodeSystem](CodeSystem-onc-problem-type.md)

### ValueSets

* [ACVPU Value Set](ValueSet-acvpu-vs.md)
* [Goal Evaluation Value Set](ValueSet-goal-evaluation-valueset.md)
* [Housing Status Value Set](ValueSet-housing-status-vs.md)
* [Inspired Oxygen Value Set](ValueSet-inspired-oxygen-vs.md)
* [NEWS2 Code Value Set](ValueSet-news2-code-vs.md)
* [NEWS2 Sub-Score Codes](ValueSet-news2-subscore-code-vs.md)
* [Nursing Intervention Value Set](ValueSet-nursing-intervention-valueset.md)
* [Nursing Problem Value Set](ValueSet-nursing-problem-valueset.md)
* [4AT Acute Change Value Set](ValueSet-onc-4at-acute-change-vs.md)
* [4AT Alertness Value Set](ValueSet-onc-4at-alertness-vs.md)
* [4AT AMT4 Value Set](ValueSet-onc-4at-amt4-vs.md)
* [4AT Attention Value Set](ValueSet-onc-4at-attention-vs.md)
* [ADPIE Nursing Process Phases](ValueSet-onc-adpie-vs.md)
* [Clinical Frailty Scale Value Set](ValueSet-onc-cfs-vs.md)
* [ONC Empathy & Relational Engagement Index](ValueSet-onc-empathy-index-vs.md)
* [Goal Target Measure ValueSet](ValueSet-onc-goal-target-measure-vs.md)
* [Mental Capacity Finding Value Set](ValueSet-onc-mca-vs.md)
* [Monk Skin Tone Scale ValueSet](ValueSet-onc-monk-scale-vs.md)
* [PBS Behaviour Function ValueSet](ValueSet-onc-pbs-function-vs.md)
* [Nursing Prognosis ValueSet](ValueSet-onc-prognosis-vs.md)
* [ONC Relational Care Outcomes](ValueSet-onc-relational-outcomes-vs.md)
* [Pain Assessment Code Value Set](ValueSet-pain-assessment-code-vs.md)
* [Problem Category Value Set](ValueSet-problem-category-valueset.md)
* [Fitzpatrick Skin Tone Value Set](ValueSet-skintone-vs.md)
* [Wound Stage Value Set](ValueSet-wound-stage-vs.md)

### Logicals

* [Relational Care Logical Model](StructureDefinition-onc-relational-care-logical.md)

### Resource Profiles

* [4AT Delirium Assessment](StructureDefinition-onc-4at-delirium.md)
* [Abbey Pain Scale](StructureDefinition-onc-abbey-pain-scale.md)
* [PBS ABC Chart](StructureDefinition-onc-abc-chart.md)
* [ACVPU Consciousness Level](StructureDefinition-onc-acvpu.md)
* [Barthel Index](StructureDefinition-onc-barthel-index.md)
* [Bladder Assessment](StructureDefinition-onc-bladder-assessment.md)
* [Blood Pressure](StructureDefinition-onc-blood-pressure.md)
* [Body Temperature](StructureDefinition-onc-body-temperature.md)
* [Bowel Assessment](StructureDefinition-onc-bowel-assessment.md)
* [Braden Scale Assessment](StructureDefinition-onc-braden-scale-assessment.md)
* [Bristol Stool Chart](StructureDefinition-onc-bristol-stool-chart.md)
* [Catheter Care](StructureDefinition-onc-catheter-care.md)
* [Clinical Frailty Scale (CFS)](StructureDefinition-onc-clinical-frailty-scale.md)
* [Continence Assessment](StructureDefinition-onc-continence-assessment.md)
* [Device Use Statement](StructureDefinition-onc-device-use-statement.md)
* [Dietary Requirements](StructureDefinition-onc-dietary-requirements.md)
* [Fluid Balance](StructureDefinition-onc-fluid-balance.md)
* [Glasgow Coma Scale](StructureDefinition-onc-glasgow-coma-scale.md)
* [ONC Goal Evaluation](StructureDefinition-onc-goal-evaluation.md)
* [Heart Rate](StructureDefinition-onc-heart-rate.md)
* [Personal Hygiene Needs Assessment](StructureDefinition-onc-hygiene-assessment.md)
* [Inspired Oxygen](StructureDefinition-onc-inspired-oxygen.md)
* [Medication Management Ability](StructureDefinition-onc-medication-ability.md)
* [Medication Self-Administration Observation](StructureDefinition-onc-medication-self-admin.md)
* [Mental Capacity Assessment](StructureDefinition-onc-mental-capacity.md)
* [Mini Mental State Examination (MMSE)](StructureDefinition-onc-mmse.md)
* [Mobility Assessment](StructureDefinition-onc-mobility-assessment.md)
* [Monk Skin Tone Observation](StructureDefinition-onc-monk-skintone-observation.md)
* [Morse Fall Scale](StructureDefinition-onc-morse-fall-scale.md)
* [MUST Score (Malnutrition Universal Screening Tool)](StructureDefinition-onc-must-score.md)
* [NEWS2 Score](StructureDefinition-onc-news2-score.md)
* [NEWS2 Sub-Score](StructureDefinition-onc-news2-subscore.md)
* [ONC NHS Patient](StructureDefinition-onc-nhs-patient.md)
* [Open Nursing Core Assessment](StructureDefinition-onc-nursing-assessment.md)
* [ONC Nursing Clinical Impression](StructureDefinition-onc-nursing-clinical-impression.md)
* [ONC Nursing Goal](StructureDefinition-onc-nursing-goal.md)
* [ONC Nursing Intervention](StructureDefinition-onc-nursing-intervention.md)
* [Nursing Problem](StructureDefinition-onc-nursing-problem.md)
* [Oral Care Needs Assessment](StructureDefinition-onc-oral-care-assessment.md)
* [Oral Health Assessment](StructureDefinition-onc-oral-health.md)
* [Oral Intake Assessment](StructureDefinition-onc-oral-intake-assessment.md)
* [Oxygen Saturation](StructureDefinition-onc-oxygen-saturation.md)
* [Pain Assessment (NRS 0-10)](StructureDefinition-onc-pain-assessment.md)
* [Patient Story](StructureDefinition-onc-patient-story.md)
* [qSOFA (Quick SOFA)](StructureDefinition-onc-qsofa.md)
* [Reasonable Adjustment](StructureDefinition-onc-reasonable-adjustment.md)
* [Relational Engagement Score](StructureDefinition-onc-relational-observation.md)
* [Respiration Rate](StructureDefinition-onc-respiration-rate.md)
* [Seizure Record](StructureDefinition-onc-seizure-record.md)
* [Skin Tone Observation](StructureDefinition-onc-skintone-observation.md)
* [Sleep Pattern](StructureDefinition-onc-sleep-pattern.md)
* [Swallowing Assessment](StructureDefinition-onc-swallowing-assessment.md)
* [Urinalysis](StructureDefinition-onc-urinalysis.md)
* [Waterlow Score](StructureDefinition-onc-waterlow-score.md)
* [What Matters to Me](StructureDefinition-onc-what-matters.md)
* [Wound Assessment](StructureDefinition-onc-wound-assessment.md)

### Extensions

* [UK Core Ethnic Category](StructureDefinition-UKCore-Extension-EthnicCategory.md)
* [Intervention Goal Reference](StructureDefinition-intervention-goal-reference.md)
* [Observation Goal Reference](StructureDefinition-observation-goal-reference.md)
* [ONC Equity Marker](StructureDefinition-onc-equity-marker.md)

### ConceptMaps

* [Mapping ONC Relational Concepts to NANDA-I](ConceptMap-ONCToNandaMapping.md)

### ImplementationGuides

* [Open Nursing Core FHIR Implementation Guide (ONC-IG)](index.md)

### Libraries

* [ONC NEWS2 Auto-Calculation Logic](Library-onc-news2-cql.md)

### PlanDefinitions

* [NEWS2 Escalation Protocol](PlanDefinition-news2-escalation-plan.md)

### Examples

* [example-nursing-problem (Condition)](Condition-example-nursing-problem.md)
* [example-patient-goal (Goal)](Goal-example-patient-goal.md)
* [example-4at-delirium (Observation)](Observation-example-4at-delirium.md)
* [example-abbey-pain (Observation)](Observation-example-abbey-pain.md)
* [example-abc-chart (Observation)](Observation-example-abc-chart.md)
* [example-bristol-stool (Observation)](Observation-example-bristol-stool.md)
* [example-clinical-frailty (Observation)](Observation-example-clinical-frailty.md)
* [example-fluid-balance (Observation)](Observation-example-fluid-balance.md)
* [example-goal-evaluation (Observation)](Observation-example-goal-evaluation.md)
* [example-mental-capacity (Observation)](Observation-example-mental-capacity.md)
* [example-oral-health (Observation)](Observation-example-oral-health.md)
* [example-patient-story (Observation)](Observation-example-patient-story.md)
* [example-reasonable-adjustment (Observation)](Observation-example-reasonable-adjustment.md)
* [example-seizure-record (Observation)](Observation-example-seizure-record.md)
* [example-urinalysis (Observation)](Observation-example-urinalysis.md)
* [example-what-matters (Observation)](Observation-example-what-matters.md)
* [observation-braden-scale (Observation)](Observation-observation-braden-scale.md)
* [observation-skin-tone (Observation)](Observation-observation-skin-tone.md)
* [patient-example-jane (Patient)](Patient-patient-example-jane.md)
* [practitioner-example (Practitioner)](Practitioner-practitioner-example.md)
* [example-nursing-intervention (Procedure)](Procedure-example-nursing-intervention.md)
