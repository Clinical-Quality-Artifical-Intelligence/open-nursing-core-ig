# Dressing and Undressing Assessment - Open Nursing Core FHIR Implementation Guide (ONC-IG) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Dressing and Undressing Assessment**

## Resource Profile: Dressing and Undressing Assessment 

| | |
| :--- | :--- |
| *Official URL*:https://opennursingcoreig.com/StructureDefinition/onc-dressing-assessment | *Version*:1.0.0 |
| Active as of 2026-07-04 | *Computable Name*:ONCDressingAssessment |

 
Assessment of assistance required for dressing and undressing, as per PRSB Personal Hygiene section. 

**Usages:**

* Examples for this Profile: [Observation/ExampleDressingAssessment](Observation-ExampleDressingAssessment.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/onc.ig|current/StructureDefinition/StructureDefinition-onc-dressing-assessment.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-onc-dressing-assessment.csv), [Excel](StructureDefinition-onc-dressing-assessment.xlsx), [Schematron](StructureDefinition-onc-dressing-assessment.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "onc-dressing-assessment",
  "url" : "https://opennursingcoreig.com/StructureDefinition/onc-dressing-assessment",
  "version" : "1.0.0",
  "name" : "ONCDressingAssessment",
  "title" : "Dressing and Undressing Assessment",
  "status" : "active",
  "date" : "2026-07-04T09:17:49+00:00",
  "publisher" : "The Open Nursing Community",
  "description" : "Assessment of assistance required for dressing and undressing, as per PRSB Personal Hygiene section.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "https://opennursingcoreig.com/StructureDefinition/onc-nursing-assessment",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation"
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "165235000",
          "display" : "Ability to dress"
        }]
      }
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    }]
  }
}

```
