# Intervention Goal Reference - Open Nursing Core FHIR Implementation Guide (ONC-IG) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Intervention Goal Reference**

## Extension: Intervention Goal Reference 

| | |
| :--- | :--- |
| *Official URL*:https://opennursingcoreig.com/StructureDefinition/intervention-goal-reference | *Version*:1.0.0 |
| Active as of 2026-07-11 | *Computable Name*:InterventionGoalReference |

Extension to link nursing interventions to the patient goals they are intended to achieve.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [ONC Nursing Intervention](StructureDefinition-onc-nursing-intervention.md)
* Examples for this Extension: [Procedure/example-nursing-intervention](Procedure-example-nursing-intervention.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/onc.ig|current/StructureDefinition/StructureDefinition-intervention-goal-reference.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-intervention-goal-reference.csv), [Excel](StructureDefinition-intervention-goal-reference.xlsx), [Schematron](StructureDefinition-intervention-goal-reference.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "intervention-goal-reference",
  "url" : "https://opennursingcoreig.com/StructureDefinition/intervention-goal-reference",
  "version" : "1.0.0",
  "name" : "InterventionGoalReference",
  "title" : "Intervention Goal Reference",
  "status" : "active",
  "date" : "2026-07-11T14:32:04+00:00",
  "publisher" : "The Open Nursing Community",
  "description" : "Extension to link nursing interventions to the patient goals they are intended to achieve.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Element"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Intervention Goal Reference",
      "definition" : "Extension to link nursing interventions to the patient goals they are intended to achieve."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "https://opennursingcoreig.com/StructureDefinition/intervention-goal-reference"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://opennursingcoreig.com/StructureDefinition/onc-nursing-goal"]
      }]
    }]
  }
}

```
